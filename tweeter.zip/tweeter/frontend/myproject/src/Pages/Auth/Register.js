
import React, { useState } from 'react';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2'

import './login.css';

function Register() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [location, setLocation] = useState('');

  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('http://localhost:5000/api/auth/register', {
        name,
        email,
        username,
        password,
        dateOfBirth,
        location,
      });

      if (response.status === 201) {
        Swal.fire({
          icon: 'success',
          title: ' You sign up successfully!',
        });
        
        navigate('/login');
      } 

      else{
        Swal.fire({
          icon: 'error',
          title: 'Email or Username already exist',
        });
      }
    } catch (error) {
      console.error(error);
      Swal.fire({
        icon: 'error',
        title: 'Failed to Sign Up',
      });
    }
  };

  return (
    <div className="container p-3 shadow-lg container-login">
      <div className="row  ">
        <div className="col-md-4 ">
          <img
            src="https://media.istockphoto.com/id/1281150061/vector/register-account-submit-access-login-password-username-internet-online-website-concept.jpg?s=612x612&w=0&k=20&c=9HWSuA9IaU4o-CK6fALBS5eaO1ubnsM08EOYwgbwGBo="
             width={400}
             height={500}
            alt=""
          />
        </div>
        <div className="col-md-8">
          <form onSubmit={handleSubmit}>
            <p className='mb-2 fs-5 fw-700 head' >Sign Up</p>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              type="text"
              className="p-1 mb-2 form-control input-bg"
              placeholder="Name"
              name="name"
              required
            />
            <input
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              type="email"
              className="p-1 mb-2 form-control input-bg"
              placeholder="Email"
              name="email"
              required
            />
            <input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              type="text"
              className="p-1 mb-2 form-control input-bg"
              placeholder="Username"
              name="username"
              required
            />
            <input
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              type="password"
              className="p-1 mb-2 form-control input-bg"
              placeholder="Password"
              name="password"
              required
            />
            <input
              value={dateOfBirth}
              onChange={(e) => setDateOfBirth(e.target.value)}
              type="date"
              className="p-1 mb-2 form-control input-bg"
              placeholder= "15-5-2003"
              name="dateOfBirth"
              required
            />
            <input
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              type="text"
              className="p-1 mb-2 form-control input-bg"
              placeholder="Location"
              name="location"
              required
            />
            <div className="mb-2 mt-1 d-grid">
              <button type="submit" className="custom-btn custom-btn-blue">
                Register
              </button>
            </div>

            <div className="my-2">
              <hr className="text-muted" />
              <h5 className="text-muted text-center">OR</h5>
              <hr className="text-muted" />
            </div>
            <div className="mt-1 mb-2 d-grid">
              <button type="button" className="custom-btn custom-btn-white">
                <span className="text-muted fs-8">If you have an account</span>
                <Link to="/login" className="ms-1 text-info fw-bold">
                  Sign In
                </Link>
              </button>
            </div>
          </form>
        </div>
      </div>
      
    </div>
  );
}

export default Register;




// import React, { useState } from 'react';
// import axios from 'axios';
// import { Link, useNavigate } from 'react-router-dom';
// import { toast, ToastContainer } from 'react-toastify';
// import 'react-toastify/dist/ReactToastify.css';
// import './login.css'

// function Register() {
//   const [name, setName] = useState('');
//   const [email, setEmail] = useState('');
//   const [username, setUsername] = useState('');
//   const [password, setPassword] = useState('');

//   const navigate = useNavigate();

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     try {
//       const response = await axios.post('http://localhost:5000/api/auth/register', {
//         name,
//         email,
//         username,
//         password,
//       });

//       if (response.status === 201) {
//         toast.success('Registration successful!');
//         navigate('/login');
//       } else {
//         const errorData = response.data;
//         toast.error(errorData.message);
//       }
//     } catch (error) {
//       console.error(error);
//       toast.error('Registration failed. Please try again.');
//     }
//   };

//   return (
//     <div className="container container-login">
//         <div className="row   p-2   shadow">
//         <div className="col-md-7">
//           <img
//             src="https://media.istockphoto.com/id/1281150061/vector/register-account-submit-access-login-password-username-internet-online-website-concept.jpg?s=612x612&w=0&k=20&c=9HWSuA9IaU4o-CK6fALBS5eaO1ubnsM08EOYwgbwGBo="
//               width={400} height={400} alt=""
//           />
//         </div>
//         <div className="col-md-5 ">
//       <form onSubmit={handleSubmit}>
//         <input
//           value={name}
//           onChange={(e) => setName(e.target.value)}
//           type="text"
//           className="p-2 mb-2 form-control input-bg"
//           placeholder="Name"
//           name="name"
//           required
//         />
//         <input
//           value={email}
//           onChange={(e) => setEmail(e.target.value)}
//           type="email"
//           className="p-2 mb-2 form-control input-bg"
//           placeholder="Email"
//           name="email"
//           required
//         />
//         <input
//           value={username}
//           onChange={(e) => setUsername(e.target.value)}
//           type="text"
//           className="p-2 mb-2 form-control input-bg"
//           placeholder="Username"
//           name="username"
//           required
//         />
//         <input
//           value={password}
//           onChange={(e) => setPassword(e.target.value)}
//           type="password"
//           className="p-2 mb-2 form-control input-bg"
//           placeholder="Password"
//           name="password"
//           required
//         />
//         <div className="mb-3 mt-2 d-grid">
//           <button type="submit" className="custom-btn custom-btn-blue">
//             Register
//           </button>
//         </div>
        
//         <div className="my-3">
//               <hr className="text-muted" />
//               <h5 className="text-muted text-center">OR</h5>
//               <hr className="text-muted" />
//             </div>
//             <div className="mt-2 mb-5 d-grid">
//               <button type="button" className="custom-btn custom-btn-white">
//                 <span className="text-muted fs-6">If you an account</span>
//                 <Link to="/register" className="ms-1 text-info fw-bold">
//                   Log In
//                 </Link>
//               </button>
//             </div>
//       </form>
//       </div>
//       </div>
//       <ToastContainer />
//     </div>
//   );
// }

// export default Register;
