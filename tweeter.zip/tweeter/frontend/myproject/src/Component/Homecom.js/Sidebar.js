import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../Context/AuthContext';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { useNavigate } from 'react-router-dom';


import './sidebar.css'

import {faComments, faHouse, faUser, faUserPlus, faArrowRightToBracket, faArrowRightFromBracket } from '@fortawesome/free-solid-svg-icons';

function Sidebar() {
  const navigate=useNavigate()

  const [auth, setAuth] = useAuth();

  const handleLogout = () => {
    setAuth({ user: null, token: '' });
    localStorage.removeItem('auth');
    navigate('/login')


  };

  // Retrieve user from localStorage and parse it
  const user = JSON.parse(localStorage.getItem('auth'));
  console.log(user);

  return (
    <div className="sidebar  ">
      

      {/* Navigation Links */}
      <nav>
      <Link className='d-block mb-4' to='/'>
          <span>
          <FontAwesomeIcon icon={faComments}size="2x" style={{color: "#74C0FC",}} />
            {/* <FontAwesomeIcon icon={faTwitter} size="2x" style={{ color: "#74C0FC" }} /> Used custom icon */}
          </span>
        </Link>
        <Link className='d-block text-decoration-none ' to="/">
          <span>
            <FontAwesomeIcon icon={faHouse} size="lg" /> Home
          </span>
        </Link>
        {user && user.user ? (
          <Link className='d-block text-decoration-none' to="/userProfile">
            <span>
              <FontAwesomeIcon icon={faUser} size="lg" /> Profile
            </span>
          </Link>
        ) : null}
      </nav>

      {/* Sign Up and Sign In Links */}
      <div className="auth-links">
        {!user ? (
          <>
            <Link className='d-block text-decoration-none' to="/register">
              <span>
                <FontAwesomeIcon icon={faUserPlus} size="lg" /> Sign Up
              </span>
            </Link>
            <Link className='d-block text-decoration-none' to="/login">
              <span>
                <FontAwesomeIcon icon={faArrowRightToBracket} size="lg" /> Sign In
              </span>
            </Link>
          </>
        ) : (
          <Link onClick={handleLogout} className=" text-decoration-none "><FontAwesomeIcon icon={faArrowRightFromBracket} size="lg" />  Logout  </Link>


        )}

      </div>
      
      

      {user && user.user && (
        <>
        <div className="user-details margins d-flex ">
          <img src={user.user.profilePic} width={30} height={30} className='rounded-circle   align-text-bottom' alt="User" />
          <p  className='ms-2  ' >{user.user.name}</p> 
          
        </div>
         <p  className='ms-4  ' >{user.user.email}</p>
        
       </>
        
      )}
      
    </div>
  );
}

export default Sidebar;
