import React, { useState, useEffect } from 'react';
import axios from 'axios';
import TweetCard from './TweetCard';
import Mytweet from './Mytweet';

// import UserProfile from '../../Pages/User/UserProfile';

function TweetList() {
  const [tweets, setTweets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [liked, setLiked] = useState(false);
  // const [content, setContent] = useState('');
  // const [replies, setReplies] = useState([]);
  // const [showReplies, setShowReplies] = useState(false);
  const user=JSON.parse(localStorage.getItem('auth'))
  
  

  const fetchTweets = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/tweet');
      setTweets(response.data.tweets);
      setLoading(false);
    } catch (error) {
      setError(error.message);
      setLoading(false);
    }
  };
  

  

  useEffect(() => {
  
    fetchTweets();

   
  }, []);
  
  

  
    
  const handleDelete = async (tweetId) => {
    try {
      await axios.delete(`http://localhost:5000/api/tweet/${tweetId}`,
      {
        headers: {
          'Authorization': `Bearer ${user.token}`,
          'Content-Type': 'application/json',
        },
      }

      );
      setTweets(tweets.filter(tweet => tweet._id !== tweetId));

    } catch (error) {
      console.error('Error deleting tweet:', error.message);
    }
  };


  const handleLike = async (tweetId,liked) => {
    try {
      // Check if the user has already liked the tweet
      
      
      if (liked) {
        // If the user has already liked the tweet, unlike it
        await axios.post(`http://localhost:5000/api/tweet/${tweetId}/dislike`,{}, {
          headers: {
            'Authorization': `Bearer ${user.token}`,
            'Content-Type': 'application/json',
          },
        });
      } else {
        // If the user has not liked the tweet yet, like it
        await axios.post(`http://localhost:5000/api/tweet/${tweetId}/like`, {}, {
          headers: {
            'Authorization': `Bearer ${user.token}`,
            'Content-Type': 'application/json',
          },
        });
      }
      setLiked(true)
          fetchTweets()
      // Update the UI or any other logic
  
    } catch (error) {
      console.error('Error toggling like:', error.message);
    }
  };
  


  const handleRetweet = async (tweetId) => {
    try {
      await axios.post(`http://localhost:5000/api/tweet/${tweetId}/retweet`,
      {
        headers: {
          'Authorization': `Bearer ${user.token}`,
          'Content-Type': 'application/json',
        },
      }
      );
      fetchTweets()
      // Update the retweet count in the UI
    } catch (error) {
      console.error('Error retweeting tweet:', error.message);
    }
  };

  const handleReply = async (tweetId,content,setContent,handleClose) => {
    try {
      await axios.post(`http://localhost:5000/api/tweet/${tweetId}/reply`, {content: content},
      {
        headers: {
          'Authorization': `Bearer ${user.token}`,
          'Content-Type': 'application/json',
        },
      }
      );
      setContent('')
      fetchTweets();
      handleClose();

    
      // Update the retweet count in the UI
    } catch (error) {
      console.error('Error retweeting tweet:', error.message);
    }
    // Implement reply functionality
  };

  if (loading) {
    return <p>Loading...</p>;
  }

  if (error) {
    return <p>Error: {error}</p>;
  }

  return (
    <div>

      {tweets.map(tweet => (
        <>
        <TweetCard
        key={tweet._id}
          tweet={tweet}
          onDelete={handleDelete}
          onLike={handleLike}
          onRetweet={handleRetweet}
          onReply={handleReply}
          getalltweets={fetchTweets}
        />

        <Mytweet
        key={tweet._id}
          tweet={tweet}
          onDelete={handleDelete}
          onLike={handleLike}
          onRetweet={handleRetweet}
          onReply={handleReply}
          getalltweets={fetchTweets}
        />

    </>
      ))}
       
        
    
     
     
    </div>
  );
}

export default TweetList;
























