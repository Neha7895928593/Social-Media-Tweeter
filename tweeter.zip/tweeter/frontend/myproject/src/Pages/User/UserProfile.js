import React from 'react';
import { useState,useEffect } from 'react';
import axios from 'axios';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBirthdayCake, faMapMarkerAlt, faUserClock } from '@fortawesome/free-solid-svg-icons';

import Sidebar from '../../Component/Homecom.js/Sidebar';
import Mytweet from '../../Component/Homecom.js/Mytweet';

import moment from 'moment';

import './userprofile.css'




function UserProfile() {
  const [mytweets, setMyTweets] = useState([])
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const formatDateOfBirth = (dob) => {
    if (!dob) return '';

    const date = new Date(dob);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  };
  // Retrieve user data from local storage
  const user = JSON.parse(localStorage.getItem('auth'));
  const userId = user?.user?._id
  const fetchUserTweets = async () => {

    try {
      const response = await axios.get(`http://localhost:5000/api/tweet/${userId}`);
      setMyTweets(response.data.tweet);

      setLoading(false);
      console.log(response.data.tweet)
    } catch (error) {
      setError(error.message);
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchUserTweets();
  }, [userId]);


  return (
    <div className="container">
      <div className="row mt-2">
        <div className="col-md-3 ">
          {/* Sidebar */}
          <Sidebar />
        </div>
        <div className="col-md-9 border-start border-end  ">
          <div className="row">
            <div className="col-12">
              Profile
            </div>

          </div>
          <div className='profile'>
            <img src={user?.user?.profilePic} width={133} height={133} className='rounded-circle round' alt="User" />
          </div>
          <div className='d-flex float-end mt-2' >
            <button type="button" className="btn btn-outline-info ms-2 ">Upload Profile Photo</button>
            <button type="button" className="btn btn-outline-secondary ms-2">Edit</button>
          </div>
          <br />
          <br />
          <br />
          <br />
          <p className='ms-4 mb-4 '>{user?.user?.name}</p>
          <div className='userinfo d-flex mb-2  '>
            <span className='ms-4' ><FontAwesomeIcon icon={faBirthdayCake} /> Birth {formatDateOfBirth(user?.user?.dateOfBirth)}</span>
            <span className='ms-5' ><FontAwesomeIcon icon={faMapMarkerAlt} /> {user?.user?.location}</span>
          </div>
          <span className='ms-4 ' ><FontAwesomeIcon icon={faUserClock} /> Joined {moment(user.user.createdAt).format('MMMM Do YYYY')}</span>
          <div className='d-flex mb-2 mt-4'>
            <span className='fw-bold ms-4 ' > 11 Following</span>
            <span className='fw-bold  ms-4' > 20 Followers</span>
          </div>


          {/* Tweet List */}
          <p className='text-center fw-bold' > Tweets and Replies </p>
          {loading ? (
            <p>Loading...</p>
          ) : error ? (
            <p>Error: {error}</p>
          ) : (
            <div>
              {mytweets.map((mytweet) => (
                <div key={mytweet._id}>
                  <Mytweet  mytweets={mytweet} />
                  {/* Render your tweet component here */}
                </div>
              ))}
            </div>
          )}
          





          {/* <TweetList userId={user?.user?._id} /> */}
        </div>
      </div>
    </div>
  );
}

export default UserProfile;
