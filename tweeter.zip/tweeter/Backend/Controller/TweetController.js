const Tweet = require('../Models/TweetModel.js');

const User=require('../Models/UserModel.js')


const createTweetController = async (req, res) => {
  try {
    console.log(req.body);
    const { content ,image} = req.body;

    if (!content) {
      return res.status(400).json({ message: 'Content is required for a tweet.' });
    }

    const tweetedBy = req.user._id; 

    const newTweet = new Tweet({
     content: content,
     image: image,
    tweetedBy:  tweetedBy,
    });

    await newTweet.save();

    res.status(201).json({
      message: 'Tweet created successfully.',
      tweet: newTweet,
    });
  } catch (error) {
    console.error('Error creating tweet:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};










//like 
const likeTweetController = async (req, res) => {
    try {
      const tweetId = req.params.id;
      const userId = req.user._id;
  
      // Check if the tweet exists
      const tweet = await Tweet.findById(tweetId)
      if (!tweet) {
        return res.status(404).json({ message: 'Tweet not found' });
      }
  
      // Check if the user has already liked the tweet
      if (tweet.likes.includes(userId)) {
        return res.status(400).json({ message: 'You cannot like an already liked tweet' });
      }
  
      // Add user ID to the likes array and save the tweet
      tweet.likes.push(userId);
      await tweet.save();
  
      res.status(200).json({ message: 'Tweet liked successfully', tweet });
    } catch (error) {
      console.error('Error liking tweet:', error);
      res.status(500).json({ message: 'Internal Server Error' });
    }
}
    //dislikle
    

const dislikeTweetController = async (req, res) => {
  try {
    const tweetId = req.params.id;
    const userId = req.user._id;

    // Check if the tweet exists
    const tweet = await Tweet.findById(tweetId);

    if (!tweet) {
      return res.status(404).json({ message: 'Tweet not found' });
    }

    // Check if the user has liked the tweet
    if (!tweet.likes.includes(userId)) {
      return res.status(400).json({ message: 'You cannot dislike a tweet you did not like' });
    }

    // Remove user ID from the likes array and save the tweet
    tweet.likes = tweet.likes.filter((id) => id.toString() !== userId.toString());
    await tweet.save();

    res.status(200).json({ message: 'Tweet disliked successfully', tweet });
  } catch (error) {
    console.error('Error disliking tweet:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};

 //replayTweet
 const replyTweetController = async (req, res) => {
  try {
    const parentTweetId = req.params.id;
    const { content } = req.body;
    const userId = req.user._id;

    // Check if the parent tweet exists
    const parentTweet = await Tweet.findById(parentTweetId);

    if (!parentTweet) {
      return res.status(404).json({ message: 'Parent tweet not found' });
    }

    // Create a new tweet for the reply
    const newReply = new Tweet({
      content,
      tweetedBy: userId,
    });
    
    // Save the new reply tweet
    await newReply.save();
    

    // Add the new reply tweet's ID to the parent tweet's replies array
    parentTweet.replies.push(newReply._id);
    await parentTweet.save();

    res.status(201).json({ message: 'Reply added successfully', reply: newReply });
  } catch (error) {
    console.error('Error replying to tweet:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
};

  //singleuser
  const getTweetById = async (req, res) => {
    try {
      const userId = req.params.id;
      const tweet = await Tweet.find({tweetedBy:userId})
      .populate('tweetedBy', '-password') // Hide user password
        .populate({
          path: 'replies',
          populate: {
            path: 'tweetedBy',
            select: '-password', // Hide user password
          },
        })
        .sort({ createdAt: 'desc' })
        .exec();
      if (!tweet) {
        return res.status(404).json({ message: 'Tweet not found' });
      }
      res.json({ tweet });
    } catch (error) {
      console.error('Error fetching tweet by ID:', error);
      res.status(500).json({ message: 'Internal Server Error' });
    }
  };
//getalltweet
const getAllTweetsController = async (req, res) => {
    try {
      // Get all tweets, populate fields with refs, and sort by createdAt in descending order
      const tweets = await Tweet.find()
        .populate('tweetedBy', '-password') // Hide user password
        .populate({
          path: 'replies',
          populate: {
            path: 'tweetedBy',
            select: '-password', // Hide user password
          },
        })
        .sort({ createdAt: 'desc' })
        .exec();
  
      res.status(200).json({ tweets });
    } catch (error) {
      console.error('Error fetching all tweets:', error);
      res.status(500).json({ message: 'Internal Server Error' });
    }
  };
  // const getRepliesByTweetId = async (req, res) => {
  //   try {
  //     const tweetId = req.params.tweetId;
  
  //     // Find the original tweet by its ID
  //     const originalTweet = await Tweet.findById(tweetId);
  
  //     if (!originalTweet) {
  //       return res.status(404).json({ message: 'Tweet not found' });
  //     }
  
  //     // Fetch replies associated with the original tweet ID
  //     const replies = await Tweet.find({ parentId: tweetId }).populate('');
  
  //     res.status(200).json({ replies });
  //   } catch (error) {
  //     console.error('Error fetching replies:', error);
  //     res.status(500).json({ message: 'Internal Server Error' });
  //   }
  // };
  
  

  //delete
  const deleteTweetController = async (req, res) => {
    try {
      const tweetId = req.params.id;
      console.log(tweetId)
      
      // Find the tweet by ID
      const tweet = await Tweet.deleteOne({_id:tweetId});
  
      // Check if the tweet exists
      if (!tweet) {
        return res.status(404).json({ message: 'Tweet not found' });
      }
  
      // Check if the logged-in user created the tweet
      
  
      // Delete the tweet
      
  
      res.status(200).json({ message: 'Tweet deleted successfully' });
    } catch (error) {
      console.error('Error deleting tweet:', error);
      res.status(500).json({ message: 'Internal Server Error' });
    }
  };
//retweet

const retweetController = async (req, res) => {
    try {
      const tweetId = req.params.id;
      const userId=req.user._id
  
      // Find the tweet by ID
      const tweet = await Tweet.findById(tweetId);;
  
      // Check if the tweet exists
      if (!tweet) {
        return res.status(404).json({ message: 'Tweet not found' });
      }
  
      // Check if the user has already retweeted
     
  
      // Add user id to the retweetBy array
      const retweeter = await User.findById(userId).select('username');

      // Ensure that retweeter object contains both _id and username properties
      if (!retweeter || !retweeter._id || !retweeter.username) {
        return res.status(400).json({ message: 'Retweeter information incomplete' });
      }
  
  
      // const retweeter = await User.findById(userId);
      console.log({retweeter:retweeter.username})

    //   const newRetweet = new Retweet({
    //     tweet: originalTweet._id,
    //     user: userId
    // });

    tweet.retweetBy.push(userId);

    
      
      // Save the tweet
      await tweet.save();
  
      res.status(200).json({ message: 'Retweeted successfully', retweeter });
    } catch (error) {
      console.error('Error retweeting:', error);
      res.status(500).json({ message: 'Internal Server Error' });
    }
  };

module.exports = { createTweetController,likeTweetController,
    dislikeTweetController,replyTweetController,
    getTweetById,getAllTweetsController,deleteTweetController,
    retweetController};
