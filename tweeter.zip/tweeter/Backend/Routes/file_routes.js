const express = require('express');
const multer = require('multer');
const path = require('path');

const router = express.Router();

// Multer configuration for file upload
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'tweetImage/');
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname);
  },
});

const upload = multer({
  storage: storage,
  limits: { fileSize: 1024 * 1024 * 10 },
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'image/jpeg' || file.mimetype === 'image/jpg' || file.mimetype === 'image/png') {
      cb(null, true);
    } else {
      cb(new Error('Only images (jpeg/jpg/png) are allowed!'), false);
    }
  }
});

// Route for file upload
router.post('/uploadFile', upload.single('file'), function (req, res) {
  res.json({ "fileName": req.file.filename });
});

// Function to handle file download
const downloadFile = (req, res) => {
  const fileName = req.params.filename;
   const Path = __basedir+"/tweetImage/";

  

  res.download(Path+fileName, (error) => {
    if (error) {
      console.error('Error downloading file:', error);
      res.status(500).send({ message: "File cannot be downloaded" });
    }
  });
};

// Route for file download
router.get('/files/:filename', downloadFile);

module.exports = router;















// const express = require('express');

// const multer = require('multer');



// const router = express.Router();

// // Multer configuration for file upload
// const storage = multer.diskStorage({
//   destination: (req,file,cb)=>{
//     cb(null,'tweetImage/')},

//   filename: (req, file, cb)=> {
//     cb(null, file.originalname);
//   },
// });

// const upload = multer({
//   storage: storage,

//   limits: { fileSize: 1024 * 1024 * 10 }, 
//   fileFilter:(req, file, cb)=> {
//     if (file.mimetype=='image/jpeg'|| file.mimetype=='image/jpg'||file.mimetype=='image/png'){
//       cb(null,true);
//     }
//     else{
//       cb(null,false);
//       return res.status(400).json({error:'Only images (jpeg/jpg/png) are allowed!'})
//     }
//   }
    
// });

// // Route for file upload
// router.post('/uploadFile', upload.single('file'), function (req, res) {
//   res.json({ "fileName": req.file.filename });
// });

// // Function to handle file download
// const downloadFile = (req, res) => {
//   const fileName = req.params.filename;
//   console.log(__dirname)
  
//    const Path = __dirname+"/tweetImage/";
//   console.log(Path)
  

//   res.download(Path+fileName, (error) => {
//     if (error) {
//       console.error('Error downloading file:', error);
//       res.status(500).send({ message: "File cannot be downloaded" });
//     }
//   });
// };

// // Route for file download
// router.get('/files/:filename', downloadFile);

// module.exports = router;
