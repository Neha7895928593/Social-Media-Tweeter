import React from 'react';
import './tweetcard.css';
import moment from 'moment';

function Mytweet({ mytweets, onDelete }) {
  if (!mytweets) {
    return null; // or any loading indicator or placeholder
  }

  const user = JSON.parse(localStorage.getItem('auth'));
  console.log(user.user._id);

  const liked = mytweets.likes.includes(mytweets.tweetedBy._id);

  const handleDelete = () => {
    onDelete(mytweets._id);
  };

  const handleLike = () => {
    // Call onLike function with tweet id
  };

  const handleRetweet = () => {
    // Call onRetweet function with tweet id
  };

  const handleReply = () => {
    // Call onReply function with tweet id
  };

  return (
    <div>
      <div className="tweet-card border p-2">
        <div className="row">
          <div className="col-11 user-info d-flex">
            <img src={mytweets.tweetedBy.profilePic} width={30} height={30} className="rounded-circle ms-2" alt="User" />
            <span className="user-name fw-bold ms-2">{mytweets.tweetedBy.name}</span>
            <span className="tweet-time ms-2">{moment(mytweets.tweetedBy.createdAt).format('ddd MMMM Do YYYY')}</span>
          </div>
          <div className=" col-1 ">
            {mytweets.tweetedBy._id === user?.user?._id && (
              <button className="action-button border-0" onClick={() => handleDelete(mytweets._id)}>
                <i className="fa-regular fa-trash-can"></i>
              </button>
            )}
          </div>
        </div>
        <div className="tweet-content ms-5 mb-1 ">{mytweets.content}</div>
        {mytweets.image !== null && <img src={mytweets.image} width="80%" height="400px" alt="image" />}
        <div className="tweet-actions mt-2 ">
          <button className="action-button border-0 ms-5" onClick={handleLike}>
            {liked ? (
              <div>
                <i className="fas fa-heart text-danger"></i>
                <span className='ms-1' >{mytweets.likes.length}</span>
              </div>
            ) : (
              <div>
                <i className="far fa-heart"></i>
                <span className='ms-1'>{mytweets.likes.length}</span>
              </div>
            )}
          </button>
          <button className="action-button ms-5 border-0  " onClick={handleRetweet}>
            <i class="fa-regular fa-comment" style={{ color: "#74C0FC" }}></i> {mytweets.replies.length}
          </button>
          <button className="action-button ms-5  border-0  " onClick={handleReply}>
            <i class="fa-solid fa-retweet" style={{ color: "#74C0FC" }}></i> {mytweets.retweetBy.length}
          </button>
        </div>
      </div>
    </div>
  );
}

export default Mytweet;
