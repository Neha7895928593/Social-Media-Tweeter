

const express = require('express');
require('./Models/Mongodb.js');
const dotenv = require('dotenv');
dotenv.config(); 
const authRoutes = require('./Routes/AuthRoutes.js');
const userRoutes = require('./Routes/UserRoutes.js');
const tweetsRoute = require('./Routes/TweetRoutes.js');
const fileRoutes = require('./Routes/file_routes.js'); 

const cors = require('cors');
global.__basedir = __dirname;

const app = express();
app.use(express.json()); 
app.use(cors());
app.use('/api/auth', authRoutes);
app.use('/api/user', userRoutes);
app.use('/api/tweet', tweetsRoute);
app.use('/api/file', fileRoutes); 

app.listen(process.env.PORT, () => {
    console.log(`Server is running at http://localhost:${process.env.PORT}`);
});


// const express = require('express');
// require('./Models/Mongodb.js');
// const dotenv = require('dotenv');
// dotenv.config(); 
// const authRoutes=require('./Routes/AuthRoutes.js')
// const userRoutes=require('./Routes/UserRoutes.js')
// const tweetsRoute=require('./Routes/TweetRoutes.js')

// const cors=require('cors')
// global.__dirname=__dirname

// const app = express();
// app.use(express.json()); 
// app.use(cors());
// app.use('/api/auth',authRoutes)
// app.use('/api/user',userRoutes)
// app.use('/api/tweet' ,tweetsRoute)
// app.use('./Routes/file_routes.js')

// app.listen(process.env.PORT, () => {
//     console.log(`Server is running at http://localhost:${process.env.PORT}`);
// });
