import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';

import LoginPage from './Pages/Auth/LoginPage';
import Register from './Pages/Auth/Register';
import Home from './Pages/Home';
import UserProfile from './Pages/User/UserProfile';

function App() {
  
  return (
    
      <Routes>
        
            <Route path="/" element={<Home />} />
            <Route path="/userProfile" element={<UserProfile />} />
            
        
            <Route path="/register" element={<Register />} />
            <Route path="/login" element={<LoginPage />} />
          
        
      </Routes>
    
  );
}

export default App;
