import './login.css';


import { Link, useNavigate } from 'react-router-dom';
import React, { useState } from 'react';
import axios from 'axios';
import Swal from 'sweetalert2'

function LoginPage() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('http://localhost:5000/api/auth/login', {
        username,
        password,
      });

      // Assuming your backend returns user data along with the token
      const { token, user } = response.data;

      // Store user data and token in local storage
      if(response.status===200){
      localStorage.setItem('auth', JSON.stringify({ token, user }));

      // Display a success toast
      Swal.fire({
        icon: 'success',
        title: 'You sign in successfully!',
      });

    }
    else{
      Swal.fire({
        icon: 'error',
        title: 'Something went Wrong',
      });
    }

      // Navigate to the home page
      navigate('/');
    } catch (error) {
      console.log(error);
      Swal.fire({
        icon: 'error',
        title: 'Failed to Sign In',
      });
    }
  };

  return (
    <div className="container  p-3 container-login">
      <div className="row p-2 shadow">
        <div className="col-md-4">
          <img
            src="https://media.istockphoto.com/id/1281150061/vector/register-account-submit-access-login-password-username-internet-online-website-concept.jpg?s=612x612&w=0&k=20&c=9HWSuA9IaU4o-CK6fALBS5eaO1ubnsM08EOYwgbwGBo="
            width={400}
            height={500}
            alt=""
          />
        </div>
        <div className="col-md-8">
          <form onSubmit={handleSubmit}>
            <p className='mb-2 fs-5 fw-700 head' >Sign In</p>
            <input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              type="text"
              className="p-1 mb-2 form-control input-bg"
              placeholder="Username"
              name="username"
            />
            <input
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              type="password"
              className="p-1 mb-2 form-control input-bg"
              placeholder="Password"
              name="password"
            />

            <div className="mb-2 mt-2 d-grid">
              <button type="submit" className="custom-btn custom-btn-blue">
                Submit
              </button>
            </div>
            <div className="my-2">
              <hr className="text-muted" />
              <h5 className="text-muted text-center">OR</h5>
              <hr className="text-muted" />
            </div>
            <div className="mt-1 mb-3 d-grid">
              <button type="button" className="custom-btn custom-btn-white">
                <span className="text-muted fs-8">If you don't have an account</span>
                <Link to="/register" className="ms-1 text-info fw-bold">
                  Sign Up
                </Link>
              </button>
            </div>
          </form>
          
        </div>
      </div>
    </div>
  );
}

export default LoginPage;
