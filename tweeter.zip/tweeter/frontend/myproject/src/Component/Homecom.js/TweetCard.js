import React from 'react';
import moment from 'moment';
import { Modal, Button, Form,} from 'react-bootstrap';
import { useState } from 'react';

import './tweetcard.css'
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';


function TweetCard({ tweet, onDelete, onLike, onRetweet, onReply, getalltweets, }) {
  const [showModal, setShowModal] = useState(false);
  const [content, setContent]=useState('')
  
  const handleClose = () => setShowModal(false);
  const handleShow = () => setShowModal(true);
  const navigate=useNavigate()
  
  const user = JSON.parse(localStorage.getItem('auth'));
  const liked = tweet.likes.includes(tweet.tweetedBy._id);
  

  console.log(tweet._id)

  const handleDelete = () => {
    // Call onDelete function with tweet id
    onDelete(tweet._id);
  };

  const handleLike = () => {

    // Call onLike function with tweet id
    onLike(tweet._id,liked);
  };

  const handleRetweet = () => {
    // Call onRetweet function with tweet id
    onRetweet(tweet._id);
  };

  const handleReply = () => {
    // Call onReply function with tweet id
    onReply(tweet._id,content,setContent,handleClose);
  };

  return (
    <div className="tweet-card border  p-2 ">
      <div className='row' >
      {tweet.retweetBy.length > 0 && (
  <p>
    <i class="fa-solid fa-retweet" style={{ color: "#74C0FC", }}></i>  Retweeted by: {tweet.retweetBy.length}

  </p>
)}

        {/* {tweet.retweetBy.length>0?   
         <i class="fa-solid fa-retweet" style={{ color: "#74C0FC", }}></i> <p> </p>
        
        :""} */}
      
        <div className="col-11 user-info d-flex">
          
          <img src={tweet.tweetedBy.profilePic} width={30} height={30} className='rounded-circle ms-2' alt="User" />
          <Link  className="user-name fw-bold ms-2 text-decoration-none ">{tweet.tweetedBy.name} </Link>
          <span className="tweet-time ms-2">{moment(tweet.tweetedBy.createdAt).format('ddd MMMM Do YYYY')}</span>

        </div>
        <div className=" col-1 ">
          {tweet.tweetedBy._id === user?.user?._id && (
            <button className="action-button border-0" onClick={() => handleDelete(tweet._id)}>
              <i className="fa-regular fa-trash-can"></i>
            </button>
          )}

        </div>




      </div>
      
      <div className="tweet-content ms-5 mb-1 ">{tweet.content}</div>
      {tweet.image !== null && <img src={tweet.image} width='80%' height='400px' alt="image" />}

      
      {/* <img src={tweet.image} width='80%' height='400px' alt="image" /> */}


      <div className="tweet-actions mt-2 ">

        
        <button className="action-button border-0" onClick={() => handleLike(tweet._id)}>  
        {liked? (
         <i className="fas fa-heart text-danger"></i>
           ) : (
            <i className="far fa-heart"></i>
          )} {tweet.likes.length}
             
         

        </button>
        
          

        

        <button className="action-button ms-5 border-0  " onClick={handleShow}>
          <i  class="fa-regular fa-comment" style={{ color: "#74C0FC", }}></i> {tweet.replies.length}
        </button>
        <Modal show={showModal}   onHide={handleClose}>
                <Modal.Header closeButton>
                  <Modal.Title>Reply</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                  <Form.Group controlId="tweetText">
                    <Form.Label>Reply Text</Form.Label>
                    <Form.Control
                      as="textarea"
                      rows={3}
                      value={content}
                      onChange={(e) => setContent(e.target.value)}
                    />
                  </Form.Group>
                  
                </Modal.Body>
                <Modal.Footer>
                  <Button variant="secondary" onClick={handleClose}>
                    Close
                  </Button>
                  <Button variant="primary" onClick={() => handleReply(tweet._id)}>
                   Reply
                  </Button>
                </Modal.Footer>
              </Modal>
        <button className="action-button ms-5  border-0  " onClick={() => handleRetweet(tweet._id)}>
          <i class="fa-solid fa-retweet" style={{ color: "#74C0FC", }}></i> {tweet.retweetBy.length}
        </button>
       
      </div>
    </div>
  );
}

export default TweetCard;
