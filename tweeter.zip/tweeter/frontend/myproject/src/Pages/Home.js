import React from 'react';
import './home.css'
import Sidebar from '../Component/Homecom.js/Sidebar';
import TweetList from '../Component/Homecom.js/TweetList';
import  { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Modal, Button, Form,} from 'react-bootstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPhotoFilm } from '@fortawesome/free-solid-svg-icons';
import axios from 'axios';


function Home() {
  const navigate = useNavigate()
  
  const [image,setImage]=useState({preview:'',data:''})
  const [showModal, setShowModal] = useState(false);
  const [content, setContent] = useState('');
  // const [mytweets,setMytweets]=useState([])

  const handleClose = () => setShowModal(false);
  const handleShow = () => setShowModal(true);

 const user=JSON.parse(localStorage.getItem('auth'))

 
  
  
  const handleFileSelect = (e) => {
    const img={
      preview:URL.createObjectURL(e.target.files[0]),
      data:e.target.files[0],

    }
    setImage(img);
  };
  const handleImageUpload = async () => {
    try {
      let formData = new FormData();
      formData.append('file', image.data);
      const response = await axios.post(
        'http://localhost:5000/api/file/uploadFile',
        formData,
        
      );
      
      return response;
    } catch (error) {
      console.error('Error uploading image:', error);
      throw error;
    }
  };
 

  const handleTweetSubmit = async () => {
    try {
      const imgres = await handleImageUpload();
      console.log(imgres.data)
      

      await axios.post(
        'http://localhost:5000/api/tweet',
        {
          content: content,
          image: `http://localhost:5000/api/file/files/${imgres.data.fileName}`,
        },
        {
          headers: {
            'Authorization': `Bearer ${user.token}`,
            'Content-Type': 'application/json',
          },
        }
      );
      setImage('');
      setContent('');
      setShowModal(false);
      navigate('/userProfile');
    } catch (error) {
      console.error('Error submitting tweet:', error);
    }
  };
  
  

  return (
    <>
    <div className="container mt-2 ">
      <div className="row  scrool ">
        <div className="col-md-3  sidebar">
          <Sidebar />
        </div>
        <div className="col-md-9 border-start border-end">
          <div className="row  mb-3">
            <div className="col-6  ">Home</div>
            <div className="col-6">
              {user?.user?
              <button onClick={handleShow} className="btn btn-primary">
                Tweet
              </button>
                  : "" }

              <Modal show={showModal} size="lg"  onHide={handleClose}>
                <Modal.Header closeButton>
                  <Modal.Title>Create New Tweet</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                  <Form.Group controlId="tweetText">
                    <Form.Label>Tweet Text</Form.Label>
                    <Form.Control
                      as="textarea"
                      rows={3}
                      value={content}
                      onChange={(e) => setContent(e.target.value)}
                    />
                  </Form.Group>
                  <Form.Group controlId="tweetImage">
                    <Form.Label   className='ms-2 mt-2' ><FontAwesomeIcon icon={faPhotoFilm} /></Form.Label>
                    <Form.Control
                    name='file'
                      type="file"

                      accept=".jpg,.png,.gif"
                      onChange={handleFileSelect}
                    />
                      {image.preview && <img  src={image.preview} 
                      width='100%' height='500px' className="img mt-2 img-responsive" />}
                  </Form.Group>
                </Modal.Body>
                <Modal.Footer>
                  <Button variant="secondary" onClick={handleClose}>
                    Close
                  </Button>
                  <Button variant="primary" onClick={handleTweetSubmit}>
                    Tweet
                  </Button>
                </Modal.Footer>
              </Modal>
            </div>
          </div>
          <TweetList />
        </div>
      </div>
    </div>
  </>
  );
}

export default Home;
